DROP TABLE IF EXISTS `#__staff_name`;
DROP TABLE IF EXISTS `#__staff_position`;
DROP TABLE IF EXISTS `#__staff_department`;
